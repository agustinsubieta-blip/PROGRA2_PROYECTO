# Cambios realizados

- Eliminada la sección independiente Productos; los productos se visualizan con «Ver más» dentro de Categorías.
- Botón Insertar producto disponible en Categorías; solicita nombre, color, precio, categoría, almacén, stock inicial y proveedor.
- La inserción de un producto, su stock inicial y su asociación con proveedor ocurre dentro de una transacción: si una acción falla, no se guarda ninguna.
- Edición y eliminación de productos se realizan desde «Ver más» en Categorías. La edición de productos modifica los datos del catálogo (nombre, color, precio y categoría); no cambia existencias ni proveedor.
- Stock es una pantalla de **solo consulta**, ordenada por precio unitario de mayor a menor.
- El menú Usuarios también elimina la sección Productos independiente.

## Base de datos requerida

Deben existir las tablas product, category, warehouse, supplier, stock(product_id,warehouse_id,quantity), product_supplier(product_id,supplier_id). La tabla product ya no debe contener warehouse_id. No hay migración SQL adicional para este cambio de interfaz.

## Limitaciones

No se han probado las operaciones contra PostgreSQL real. Usar los endpoints actuales de Spring Security y CSRF. Al borrar categorías o almacenes, respetar el comportamiento ON DELETE CASCADE configurado en PostgreSQL.
