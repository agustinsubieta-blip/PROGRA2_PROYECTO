-- MIGRACIÓN PRODUCTO / ALMACÉN / STOCK (PostgreSQL)
-- Ejecutar una sola vez en pgAdmin sobre la BD usada por la aplicación.
-- HACER BACKUP ANTES. No elimina datos de product ni de stock; solo quita
-- product.warehouse_id y reorganiza las claves foráneas.
-- Si falla alguna instrucción, se revierte toda la transacción.

BEGIN;

-- Almacén y producto pasan a relacionarse exclusivamente por stock.
-- PostgreSQL elimina automáticamente el FK de esta columna al borrarla.
ALTER TABLE product DROP COLUMN IF EXISTS warehouse_id;

-- Un registro de stock por cada par producto/almacén, necesario para ON CONFLICT.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM stock
        GROUP BY product_id, warehouse_id
        HAVING COUNT(*) > 1
    ) THEN
        RAISE EXCEPTION 'Hay filas repetidas en stock para un mismo producto y almacén. Unificá esas cantidades antes de ejecutar la migración.';
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_stock_product_warehouse
    ON stock (product_id, warehouse_id);

-- Al eliminar un almacén, se elimina su stock, NO el producto del catálogo.
ALTER TABLE stock DROP CONSTRAINT IF EXISTS stock_warehouse_id_fkey;
ALTER TABLE stock ADD CONSTRAINT stock_warehouse_id_fkey
    FOREIGN KEY (warehouse_id) REFERENCES warehouse(id) ON DELETE CASCADE;

-- Al eliminar un producto, se eliminan sus existencias.
ALTER TABLE stock DROP CONSTRAINT IF EXISTS stock_product_id_fkey;
ALTER TABLE stock ADD CONSTRAINT stock_product_id_fkey
    FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE CASCADE;

-- Tu BD también contiene location_product; la relación al almacén
-- debe tener cascada para que no impida eliminar almacenes.
-- Se busca el nombre real de la FK, incluso si PostgreSQL la truncó.
DO $$
DECLARE fk RECORD;
BEGIN
    FOR fk IN
        SELECT c.conname, n.nspname, t.relname
        FROM pg_constraint c
        JOIN pg_class t ON t.oid = c.conrelid
        JOIN pg_namespace n ON n.oid = t.relnamespace
        JOIN pg_class ref ON ref.oid = c.confrelid
        WHERE c.contype = 'f'
          AND t.relname = 'location_product'
          AND ref.relname = 'warehouse'
    LOOP
        EXECUTE format('ALTER TABLE %I.%I DROP CONSTRAINT %I',
                       fk.nspname, fk.relname, fk.conname);
        EXECUTE format('ALTER TABLE %I.%I ADD CONSTRAINT %I FOREIGN KEY (warehouse_id) REFERENCES warehouse(id) ON DELETE CASCADE',
                       fk.nspname, fk.relname, fk.conname);
    END LOOP;
END $$;

COMMIT;

-- Verificá luego:
-- SELECT column_name FROM information_schema.columns WHERE table_name='product';
-- SELECT conrelid::regclass, confrelid::regclass, pg_get_constraintdef(oid)
-- FROM pg_constraint WHERE contype='f' ORDER BY conrelid::regclass::text;
