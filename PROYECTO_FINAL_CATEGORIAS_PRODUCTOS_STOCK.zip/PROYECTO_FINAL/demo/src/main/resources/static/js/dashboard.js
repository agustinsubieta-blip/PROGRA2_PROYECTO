'use strict';
const $ = (id) => document.getElementById(id);
const state = { categories:[], products:[], warehouses:[], suppliers:[], stock:[], selectedWarehouse:'' };
const crudConfig = $('crudConfig');
const canManage = crudConfig?.dataset.canManage === 'true';
const isAdmin = crudConfig?.dataset.isAdmin === 'true';
const actionButtons = (resource, id) => !canManage ? '' :
  `<button type="button" class="btn btn-outline-primary btn-sm me-2" data-edit-resource="${resource}" data-edit-id="${Number(id)}">Editar</button>` +
  (isAdmin ? `<button type="button" class="btn btn-outline-danger btn-sm" data-delete-resource="${resource}" data-delete-id="${Number(id)}">Borrar</button>` : '');
const cols = (base) => base + (canManage ? 1 : 0);
const resourceLabel = {categories:'categoría',products:'producto',warehouses:'almacén',suppliers:'proveedor'};
const resourceList = {categories:'categories',products:'products',warehouses:'warehouses',suppliers:'suppliers'};
const modal = window.bootstrap ? new bootstrap.Modal($('crudModal')) : null;
let editingResource = null, editingId = null;
const money = (value) => 'Bs ' + Number(value ?? 0).toLocaleString('es-BO', { minimumFractionDigits:2, maximumFractionDigits:2 });
const safe = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function alertMsg(message, error=false) {
  const box=$('flash'); box.textContent=message; box.className='alert ' + (error?'alert-danger':'alert-success'); box.style.display='block';
  window.setTimeout(()=>box.style.display='none',6500);
}
async function api(url,options={}) {
  const r = await fetch(url,{credentials:'same-origin',...options});
  if (!r.ok) { let message='Error HTTP '+r.status; try {const body=await r.json(); message=body.detail||body.message||message;} catch {} throw new Error(message); }
  return r.json();
}
function empty(cols,msg) { return `<tr><td colspan="${cols}" class="text-center text-muted py-4">${safe(msg)}</td></tr>`; }
function showPanel(name) {
  const names={inicio:['Panel principal','Resumen general del inventario'],categorias:['Categorías','Productos y cantidades por categoría'],almacenes:['Almacenes','Categorías y productos disponibles por almacén'],proveedores:['Proveedores','Información de los proveedores'],stock:['Stock','Existencias y valor del inventario']};
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id==='panel-'+name));
  document.querySelectorAll('[data-panel]').forEach(b=>b.classList.toggle('active',b.dataset.panel===name));
  $('pageTitle').textContent=names[name][0];$('pageSubtitle').textContent=names[name][1];
  history.replaceState(null,'','#'+name);
}
document.querySelectorAll('[data-panel]').forEach(b=>b.addEventListener('click',()=>showPanel(b.dataset.panel)));
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>showPanel(b.dataset.open)));
function renderProductsTable(items) {
  if (!items.length) return `<p class="text-muted mb-0">No hay productos en esta categoría.</p>`;
  return `<div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Producto</th><th>Color</th><th>Precio</th><th>Cantidad</th><th>Proveedor</th>${canManage?'<th>Acciones</th>':''}</tr></thead><tbody>${items.map(p=>`<tr><td>${safe(p.name)}</td><td>${safe(p.color||'—')}</td><td>${money(p.price)}</td><td>${safe(p.quantity??0)}</td><td>${safe(p.supplierName ?? p.suppliername ?? "Sin proveedor")}</td>${canManage?`<td>${actionButtons('products',p.id)}</td>`:''}</tr>`).join('')}</tbody></table></div>`;
}
async function loadCategories() {
  const id=$('categoryWarehouse').value;state.selectedWarehouse=id;
  try {
    const categories=id?await api('/warehouses/'+encodeURIComponent(id)+'/categories'):state.categories;
    $('categoriesBody').innerHTML=categories.length?categories.map(c=>`<tr><td>${safe(c.name)}</td><td><button type="button" class="btn btn-outline-primary btn-sm me-2" data-category="${Number(c.id)}">Ver más</button>${actionButtons('categories',c.id)}</td></tr><tr class="expanded d-none" id="detail-category-${Number(c.id)}"><td colspan="2"><span class="text-muted">Cargando…</span></td></tr>`).join(''):empty(2,'No hay categorías con productos en este almacén.');
  } catch(e) { $('categoriesBody').innerHTML=empty(2,e.message); }
}
$('categoriesBody').addEventListener('click',async (event)=>{
  const button=event.target.closest('button[data-category]');if(!button)return;
  const id=button.dataset.category, row=$('detail-category-'+id);
  if(!row.classList.contains('d-none')) {row.classList.add('d-none');button.textContent='Ver más';return;}
  row.classList.remove('d-none');button.textContent='Ver menos';
  try {
    const url=state.selectedWarehouse?`/warehouses/${encodeURIComponent(state.selectedWarehouse)}/categories/${encodeURIComponent(id)}/products`:`/categories/${encodeURIComponent(id)}/products`;
    const data=await api(url);row.firstElementChild.innerHTML=renderProductsTable(data);
  } catch(e) { row.firstElementChild.textContent='No se pudieron cargar los productos: '+e.message; }
});
$('reloadCategories').addEventListener('click',loadCategories);
$('categoryWarehouse').addEventListener('change',loadCategories);
function renderProducts() {
  // Los productos se muestran dentro de Categorías, no en una pantalla separada.
  $('productCount').textContent=state.products.length;
}
function renderWarehouses() {
  $('warehousesBody').innerHTML=state.warehouses.length?state.warehouses.map(w=>`<tr><td>${safe(w.name)}</td><td>${safe(w.location||'—')}</td><td><button type="button" class="btn btn-outline-primary btn-sm me-2" data-warehouse="${Number(w.id)}">Ver categorías</button>${actionButtons('warehouses',w.id)}</td></tr>`).join(''):empty(3,'No hay almacenes registrados.');
  $('categoryWarehouse').innerHTML='<option value="">Todos los almacenes (stock total)</option>'+state.warehouses.map(w=>`<option value="${Number(w.id)}">${safe(w.name)}</option>`).join('');

}
$('warehousesBody').addEventListener('click',async(e)=>{
  const b=e.target.closest('[data-warehouse]');if(!b)return;
  const id=b.dataset.warehouse;const w=state.warehouses.find(x=>String(x.id)===id);
  $('warehouseDetails').classList.remove('d-none');$('warehouseDetailsTitle').textContent='Productos de '+(w?.name||'almacén');
  const box=$('warehouseDetailsContent');box.textContent='Cargando categorías…';
  try {
    const categories=await api(`/warehouses/${encodeURIComponent(id)}/categories`);
    if (!categories.length) {box.textContent='No hay categorías con stock en este almacén.';return;}
    const groups=await Promise.all(categories.map(async c=>({name:c.name,products:await api(`/warehouses/${encodeURIComponent(id)}/categories/${encodeURIComponent(c.id)}/products`)})));
    box.innerHTML=groups.map(g=>`<div class="mt-3"><h6>${safe(g.name)}</h6>${renderProductsTable(g.products)}</div>`).join('');
  } catch(err) {box.textContent='No se pudieron cargar los datos: '+err.message;}
});
function renderSuppliers() {
 $('suppliersBody').innerHTML=state.suppliers.length?state.suppliers.map(s=>`<tr><td>${safe(s.name)}</td><td>${safe(s.location||'—')}</td>${canManage?`<td>${actionButtons('suppliers',s.id)}</td>`:''}</tr>`).join(''):empty(cols(2),'No hay proveedores registrados.');
}
function renderStock() {
 $('stockBody').innerHTML=state.stock.length?[...state.stock].sort((a,b)=>Number(b.price)-Number(a.price)).map(s=>`<tr><td>${safe(s.productName ?? s.productname)}</td><td>${safe(s.warehouseName ?? s.warehousename)}</td><td>${safe(s.quantity)}</td><td>${money(s.price)}</td><td>${money(s.totalValue ?? s.totalvalue ?? (Number(s.quantity) * Number(s.price)))}</td></tr>`).join(''):empty(5,'No hay existencias registradas.');

}
async function refreshData() {
 const jobs=[['categories','/categories'],['products','/api/inventory/products'],['warehouses','/warehouses'],['suppliers','/suppliers'],['stock','/api/inventory/stock']];
 const results=await Promise.allSettled(jobs.map(async ([key,url])=>({key,data:await api(url)})));
 results.forEach((res,i)=>{if(res.status==='fulfilled')state[res.value.key]=res.value.data;else {state[jobs[i][0]]=[];alertMsg('No se pudo cargar '+jobs[i][0]+': '+res.reason.message,true);}});
 renderProducts();renderWarehouses();renderSuppliers();renderStock();await loadCategories();
 try { const total=await api('/api/inventory/total');$('totalInicio').textContent=money(total);$('totalStock').textContent=money(total); } catch(e){alertMsg('No se pudo actualizar el total: '+e.message,true);}
}
refreshData();
const initial=location.hash.slice(1);if(['inicio','categorias','almacenes','proveedores','stock'].includes(initial))showPanel(initial);


// Crear / editar / eliminar entidades del inventario. Las autorizaciones reales están en SecurityConfig.
if (canManage && modal) {
  const f=$('crudForm');
  function openCrud(resource, id=null) {
    const row = id == null ? null : state[resourceList[resource]].find(x=>Number(x.id)===Number(id));
    if (id != null && !row) {alertMsg('No se encontró el registro',true);return;}
    editingResource=resource;editingId=id;
    f.reset();
    $('crudModalTitle').textContent=(id==null?'Insertar ':'Editar ')+resourceLabel[resource];
    $('crudLocationGroup').classList.toggle('d-none', resource!=='warehouses'&&resource!=='suppliers');
    $('crudProductGroup').classList.toggle('d-none',resource!=='products');
    const isNewProduct=resource==='products' && id==null;
    $('crudProductInitialGroup').classList.toggle('d-none', !isNewProduct);
    $('crudWarehouse').required=isNewProduct;
    $('crudQuantity').required=isNewProduct;
    $('crudSupplier').required=resource==='products';
    $('crudWarehouse').innerHTML=state.warehouses.map(w=>`<option value="${Number(w.id)}">${safe(w.name)}</option>`).join('');
    $('crudSupplier').innerHTML=state.suppliers.map(s=>`<option value="${Number(s.id)}">${safe(s.name)}</option>`).join('');
    $('crudName').maxLength=resource==='categories'?80:100;
    $('crudLocation').maxLength=resource==='warehouses'?500:100;
    $('crudLocation').required=resource==='warehouses'||resource==='suppliers';
    $('crudColor').required=resource==='products';
    $('crudPrice').required=resource==='products';
    $('crudCategory').required=resource==='products';
    $('crudCategory').innerHTML=state.categories.map(c=>`<option value="${Number(c.id)}">${safe(c.name)}</option>`).join('');
    if(row) {
      $('crudName').value=row.name??'';
      $('crudLocation').value=row.location??'';
      if(resource==='products'){
        $('crudColor').value=row.color??'';
        $('crudPrice').value=row.price??'';
        $('crudCategory').value=row.categoryId??'';
        $('crudSupplier').value=row.supplierId??'';
      }
    }
    if (resource==='products' && !state.categories.length) {
      alertMsg('Para crear o editar un producto necesitás al menos una categoría.',true);return;
    }
    if (resource==='products' && !state.suppliers.length) {
      alertMsg('Para guardar un producto necesitás al menos un proveedor.',true);return;
    }
    if (isNewProduct && !state.warehouses.length) {
      alertMsg('Para insertar un producto necesitás al menos un almacén y un proveedor.',true);return;
    }
    modal.show();
  }
  document.querySelectorAll('[data-add-resource]').forEach(b=>b.addEventListener('click',()=>openCrud(b.dataset.addResource)));
  document.querySelectorAll('#categoriesBody,#warehousesBody,#warehouseDetailsContent,#suppliersBody').forEach(body=>{
    body.addEventListener('click',async(e)=>{
      const edit=e.target.closest('[data-edit-resource]');
      if(edit) {openCrud(edit.dataset.editResource,edit.dataset.editId);return;}
      const del=e.target.closest('[data-delete-resource]');
      if(!del || !isAdmin)return;
      const resource=del.dataset.deleteResource,id=Number(del.dataset.deleteId);
      const row=state[resourceList[resource]].find(x=>Number(x.id)===id);
      if(!window.confirm('¿Querés borrar '+resourceLabel[resource]+' "'+(row?.name??'')+'"? Esta acción no se puede deshacer.'))return;
      del.disabled=true;
      try {
        await writeCrud(`/api/manage/${resource}/${id}`,'DELETE');
        alertMsg('Registro eliminado correctamente.');await refreshData();
      }catch(err){alertMsg(err.message,true);}finally{del.disabled=false;}
    });
  });
  f.addEventListener('submit',async(e)=>{
    e.preventDefault();
    const resource=editingResource,id=editingId;
    if(!resource)return;
    const data={name:$('crudName').value.trim()};
    if(resource==='warehouses'||resource==='suppliers')data.location=$('crudLocation').value.trim();
    if(resource==='products'){
      data.color=$('crudColor').value.trim();
      data.price=Number($('crudPrice').value);
      data.categoryId=Number($('crudCategory').value);
      data.supplierId=Number($('crudSupplier').value);
      if (id==null) {
        data.warehouseId=Number($('crudWarehouse').value);
        data.quantity=Number($('crudQuantity').value);
      }
    }
    $('crudSave').disabled=true;
    try {
      await writeCrud(`/api/manage/${resource}`+(id==null?'':`/${Number(id)}`),id==null?'POST':'PUT',data);
      modal.hide();alertMsg('Registro guardado correctamente.');await refreshData();
    }catch(err){alertMsg(err.message,true);modal.hide();}finally{$('crudSave').disabled=false;}
  });
}
async function writeCrud(url,method,data=null) {
  const headers={};
  if(crudConfig?.dataset.csrfHeader && crudConfig?.dataset.csrfToken)
      headers[crudConfig.dataset.csrfHeader]=crudConfig.dataset.csrfToken;
  if(data!=null)headers['Content-Type']='application/json';
  return api(url,{method,headers,...(data!=null?{body:JSON.stringify(data)}:{})});
}
