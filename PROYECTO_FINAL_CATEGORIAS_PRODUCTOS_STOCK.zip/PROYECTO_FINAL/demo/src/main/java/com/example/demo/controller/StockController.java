package com.example.demo.controller;

import com.example.demo.service.StockService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/stock")
public class StockController {
    private final StockService stockService;

    public StockController(StockService stockService) {
        this.stockService = stockService;
    }

    @GetMapping
    public List<Map<String, Object>> listStock() {
        return stockService.getStockDetails();
    }

    @GetMapping("/total-value")
    public BigDecimal totalValue() {
        return stockService.getTotalStockValue();
    }
}
