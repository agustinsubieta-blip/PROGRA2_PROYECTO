package com.example.demo.repository;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;

import java.util.List;
import java.util.Optional;

public abstract class BaseRepository<T> {

    protected final Jdbi jdbi;

    private final Class<T> type;
    private final String table;

    public BaseRepository(Jdbi jdbi, Class<T> type, String table) {
        this.jdbi = jdbi;
        this.type = type;
        this.table = table;
    }

    // Obtener todos
    public List<T> findAll() {

        String sql = "SELECT * FROM " + table;

        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql)
                    .mapToBean(type)
                    .list();
        }
    }

    // Buscar por ID
    public Optional<T> findById(Long id) {

        String sql = "SELECT * FROM " + table + " WHERE id = :id";

        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql)
                    .bind("id", id)
                    .mapToBean(type)
                    .findOne();
        }
    }

    // Eliminar por ID
    public int delete(Long id) {

        String sql = "DELETE FROM " + table + " WHERE id = :id";

        try (Handle handle = jdbi.open()) {
            return handle.createUpdate(sql)
                    .bind("id", id)
                    .execute();
        }
    }
}