package com.example.demo.service;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.repository.WarehouseRepository;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class WarehouseService {

    private final WarehouseRepository warehouseRepository;

    public WarehouseService(WarehouseRepository warehouseRepository) {
        this.warehouseRepository = warehouseRepository;
    }

    public List<Warehouse> getAllWarehouses() {
        return warehouseRepository.findAll();
    }

    public List<Category> getCategoriesByWarehouse(Long warehouseId) {
        return warehouseRepository.findCategoriesByWarehouse(warehouseId);
    }

    public List<ProductWithStock> getProductsByWarehouseAndCategory(
            Long warehouseId, Long categoryId) {

        return warehouseRepository.findProductsByWarehouseAndCategory(
                warehouseId, categoryId
        );
    }
}