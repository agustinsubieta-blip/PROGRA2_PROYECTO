package com.example.demo.service;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.repository.WarehouseRepository;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class WarehouseService {

    private final WarehouseRepository warehouseRepository;

    public WarehouseService(WarehouseRepository warehouseRepository) {
        this.warehouseRepository = warehouseRepository;
    }

    public List<Warehouse> getAllWarehouses() {
        return warehouseRepository.findAll();
    }

    public List<Category> getCategoriesByWarehouse(Long warehouseId) {
        return warehouseRepository.findCategoriesByWarehouse(warehouseId);
    }

    public List<ProductWithStock> getProductsByWarehouseAndCategory(
            Long warehouseId, Long categoryId) {

        return warehouseRepository.findProductsByWarehouseAndCategory(
                warehouseId, categoryId
        );
    }

    public void saveWarehouse(Long id, String name, String location) {
        String cleanName = InventoryValidation.required(name, "El nombre", 100);
        String cleanLocation = InventoryValidation.required(location, "La ubicación", 500);
        int rows;
        if (id == null) {
            rows = warehouseRepository.createWarehouse(cleanName, cleanLocation);
        } else {
            rows = warehouseRepository.editWarehouse(id, cleanName, cleanLocation);
        }
        InventoryValidation.check(rows);
    }

    public void deleteWarehouse(Long id) {
        InventoryValidation.check(warehouseRepository.deleteWarehouse(
                InventoryValidation.requiredId(id, "un almacén")));
    }
}