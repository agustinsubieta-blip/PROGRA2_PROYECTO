package com.example.demo.service;

import java.math.BigDecimal;

// Pequeñas comprobaciones compartidas por los Services.
public final class InventoryValidation {
    private InventoryValidation() {}

    public static String required(String value, String field, int max) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(field + " es obligatorio");
        }
        String clean = value.trim();
        if (clean.length() > max) {
            throw new IllegalArgumentException(field + " no puede superar " + max + " caracteres");
        }
        return clean;
    }

    public static Long requiredId(Long id, String field) {
        if (id == null || id < 1) {
            throw new IllegalArgumentException("Seleccioná " + field);
        }
        return id;
    }

    public static BigDecimal validPrice(BigDecimal price) {
        if (price == null || price.signum() < 0 || price.scale() > 2
                || price.compareTo(new BigDecimal("99999999.99")) > 0) {
            throw new IllegalArgumentException("Precio inválido: máximo 99999999.99 y dos decimales");
        }
        return price;
    }

    public static void check(int rows) {
        if (rows != 1) {
            throw new IllegalArgumentException("No se encontró el registro que querés modificar");
        }
    }
}
