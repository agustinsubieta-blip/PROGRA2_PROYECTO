package com.example.demo.config;

import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AdminInitializer implements CommandLineRunner {

    private final UserService userService;
    private final UserRepository userRepository;

    public AdminInitializer(
            UserService userService,
            UserRepository userRepository) {

        this.userService = userService;
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) {

        String username = "admin";
        String password = System.getenv("INITIAL_ADMIN_PASSWORD");

        if (username == null || username.isBlank()
                || password == null || password.isBlank()) {
            return;
        }

        if (userRepository.findByUsername(username).isPresent()) {
            return;
        }

        userService.createUser(username, password, "ADMIN");

        System.out.println("Administrador inicial creado correctamente");
    }
}