package com.example.demo.controller;

import com.example.demo.dto.ProductInput;
import com.example.demo.model.ProductWithStock;
import java.util.List;
import com.example.demo.service.ProductService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductController {
    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public List<ProductWithStock> listProducts() {
        return productService.getAllProductsWithStock();
    }

    @PostMapping
    public boolean addProduct(@RequestBody ProductInput input) {
        productService.createProduct(input.getName(), input.getColor(), input.getPrice(),
                input.getCategoryId(), input.getWarehouseId(), input.getQuantity(),
                input.getSupplierId());
        return true;
    }

    @PutMapping("/{id}")
    public boolean editProduct(@PathVariable Long id, @RequestBody ProductInput input) {
        productService.saveProduct(id, input.getName(), input.getColor(), input.getPrice(),
                input.getCategoryId(), input.getSupplierId());
        return true;
    }

    @DeleteMapping("/{id}")
    public boolean removeProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return true;
    }
}
