package com.example.demo.service;

import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;

    public CategoryService(
        CategoryRepository categoryRepository,
        ProductRepository productRepository) {

    this.categoryRepository = categoryRepository;
    this.productRepository = productRepository;
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public Category createCategory(String name) {

        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException(
                "El nombre es obligatorio"
            );
        }

        if (name.length() > 80) {
            throw new IllegalArgumentException(
                "El nombre no puede superar 80 caracteres"
            );
        }

        Category category = new Category(name);

        return categoryRepository.save(category);
    }
    public List<ProductWithStock> getProductsByCategory(Long categoryId) {

    return productRepository.findByCategoryWithStock(categoryId);
    }
    
    public Category getCategoryById(Long id) {

    return categoryRepository.findById(id)
            .orElseThrow();
}

}