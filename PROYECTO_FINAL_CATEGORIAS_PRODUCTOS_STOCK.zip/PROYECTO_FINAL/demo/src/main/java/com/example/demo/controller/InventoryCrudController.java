package com.example.demo.controller;

import com.example.demo.service.InventoryCrudService;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.dao.DataIntegrityViolationException;
import org.jdbi.v3.core.statement.UnableToExecuteStatementException;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/manage")
public class InventoryCrudController {
    private final InventoryCrudService service;
    public InventoryCrudController(InventoryCrudService service) { this.service=service; }

    public record CategoryInput(String name) {}
    public record NamedInput(String name, String location) {}
    public record ProductInput(String name, String color, BigDecimal price,
                               Long categoryId, Long warehouseId, Integer quantity,
                               Long supplierId) {}

    @PostMapping("/categories")
    public Map<String,Boolean> addCategory(@RequestBody CategoryInput input) {
        service.saveCategory(null,input.name()); return Map.of("success",true);
    }
    @PutMapping("/categories/{id}")
    public Map<String,Boolean> editCategory(@PathVariable Long id,@RequestBody CategoryInput input) {
        service.saveCategory(id,input.name()); return Map.of("success",true);
    }
    @DeleteMapping("/categories/{id}")
    public Map<String,Boolean> removeCategory(@PathVariable Long id) {
        service.deleteCategory(id); return Map.of("success",true);
    }

    @PostMapping("/products")
    public Map<String,Boolean> addProduct(@RequestBody ProductInput input) {
        service.createProduct(input.name(), input.color(), input.price(), input.categoryId(),
                              input.warehouseId(), input.quantity(), input.supplierId());
        return Map.of("success",true);
    }
    @PutMapping("/products/{id}")
    public Map<String,Boolean> editProduct(@PathVariable Long id,@RequestBody ProductInput input) {
        service.saveProduct(id,input.name(),input.color(),input.price(),input.categoryId(),input.supplierId());
        return Map.of("success",true);
    }
    @DeleteMapping("/products/{id}")
    public Map<String,Boolean> removeProduct(@PathVariable Long id) {
        service.deleteProduct(id); return Map.of("success",true);
    }

    @PostMapping("/warehouses")
    public Map<String,Boolean> addWarehouse(@RequestBody NamedInput input) {
        service.saveWarehouse(null,input.name(),input.location()); return Map.of("success",true);
    }
    @PutMapping("/warehouses/{id}")
    public Map<String,Boolean> editWarehouse(@PathVariable Long id,@RequestBody NamedInput input) {
        service.saveWarehouse(id,input.name(),input.location()); return Map.of("success",true);
    }
    @DeleteMapping("/warehouses/{id}")
    public Map<String,Boolean> removeWarehouse(@PathVariable Long id) {
        service.deleteWarehouse(id); return Map.of("success",true);
    }

    @PostMapping("/suppliers")
    public Map<String,Boolean> addSupplier(@RequestBody NamedInput input) {
        service.saveSupplier(null,input.name(),input.location()); return Map.of("success",true);
    }
    @PutMapping("/suppliers/{id}")
    public Map<String,Boolean> editSupplier(@PathVariable Long id,@RequestBody NamedInput input) {
        service.saveSupplier(id,input.name(),input.location()); return Map.of("success",true);
    }
    @DeleteMapping("/suppliers/{id}")
    public Map<String,Boolean> removeSupplier(@PathVariable Long id) {
        service.deleteSupplier(id); return Map.of("success",true);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String,String> badInput(IllegalArgumentException e) {
        return Map.of("message",e.getMessage());
    }
    @ExceptionHandler({UnableToExecuteStatementException.class,DataIntegrityViolationException.class})
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String,String> databaseConstraint(Exception e) {
        return Map.of("message","No se pudo guardar o eliminar: comprobá que los datos sean válidos y que no existan registros relacionados (productos, stock u otros). ");
    }
}
