package com.example.demo.service;

import com.example.demo.model.Supplier;
import com.example.demo.repository.SupplierRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    private final SupplierRepository supplierRepository;

    public SupplierService(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    public void saveSupplier(Long id, String name, String location) {
        String cleanName = InventoryValidation.required(name, "El nombre", 100);
        String cleanLocation = InventoryValidation.required(location, "La ubicación", 100);
        int rows;
        if (id == null) {
            rows = supplierRepository.createSupplier(cleanName, cleanLocation);
        } else {
            rows = supplierRepository.editSupplier(id, cleanName, cleanLocation);
        }
        InventoryValidation.check(rows);
    }

    public void deleteSupplier(Long id) {
        InventoryValidation.check(supplierRepository.deleteSupplier(
                InventoryValidation.requiredId(id, "un proveedor")));
    }
}