package com.example.demo.controller;

import com.example.demo.service.CategoryService;
import com.example.demo.service.StockService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

@Controller
public class HomeController {

    private final CategoryService categoryService;
    private final StockService stockService;

    public HomeController(
            CategoryService categoryService,
            StockService stockService) {

        this.categoryService = categoryService;
        this.stockService = stockService;
    }

   @GetMapping("/")
    public String home(Model model, Authentication authentication) {

    model.addAttribute("categories", categoryService.getAllCategories());

    model.addAttribute("totalStockValue", stockService.getTotalStockValue());

    boolean isAdmin = false;

    for (GrantedAuthority authority : authentication.getAuthorities()) {

        if (authority.getAuthority().equals("ROLE_ADMIN")) {
            isAdmin = true;
            break;
        }
    }

    model.addAttribute("isAdmin", isAdmin);
    boolean canManageStock = authentication.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")
                    || a.getAuthority().equals("ROLE_EMPLOYEE"));
    model.addAttribute("canManageStock", canManageStock);
    model.addAttribute("canManageInventory", canManageStock);

    // Nombre del usuario autenticado
    model.addAttribute("username", authentication.getName());

    return "index";
    }
}