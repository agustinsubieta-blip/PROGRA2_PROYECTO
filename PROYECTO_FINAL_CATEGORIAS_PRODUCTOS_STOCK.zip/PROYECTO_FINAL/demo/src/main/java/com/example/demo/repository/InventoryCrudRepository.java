package com.example.demo.repository;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class InventoryCrudRepository {
    private final Jdbi jdbi;

    public InventoryCrudRepository(Jdbi jdbi) { this.jdbi = jdbi; }

    public int createCategory(String name) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("INSERT INTO category(name) VALUES (:name)")
                    .bind("name", name).execute();
        }
    }
    public int editCategory(Long id, String name) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("UPDATE category SET name=:name WHERE id=:id")
                    .bind("name",name).bind("id",id).execute();
        }
    }
    public int deleteCategory(Long id) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("DELETE FROM category WHERE id=:id").bind("id",id).execute();
        }
    }

    public int createSupplier(String name, String location) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("INSERT INTO supplier(name,location) VALUES (:name,:location)")
                    .bind("name",name).bind("location",location).execute();
        }
    }
    public int editSupplier(Long id, String name, String location) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("UPDATE supplier SET name=:name,location=:location WHERE id=:id")
                    .bind("name",name).bind("location",location).bind("id",id).execute();
        }
    }
    public int deleteSupplier(Long id) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("DELETE FROM supplier WHERE id=:id").bind("id",id).execute();
        }
    }

    public int createWarehouse(String name, String location) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("INSERT INTO warehouse(name,location) VALUES (:name,:location)")
                    .bind("name",name).bind("location",location).execute();
        }
    }
    public int editWarehouse(Long id, String name, String location) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("UPDATE warehouse SET name=:name,location=:location WHERE id=:id")
                    .bind("name",name).bind("location",location).bind("id",id).execute();
        }
    }
    public int deleteWarehouse(Long id) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("DELETE FROM warehouse WHERE id=:id").bind("id",id).execute();
        }
    }

    // Alta atómica: producto + existencias en un almacén + asociación con proveedor.
    // Si falla cualquiera de las tres inserciones, se deshace toda la operación.
    public int createProduct(String name, String color, BigDecimal price,
                             Long categoryId, Long warehouseId, Integer quantity,
                             Long supplierId) {
        try (Handle h = jdbi.open()) {
            h.begin();
            try {
                Long productId = h.createQuery("""
                        INSERT INTO product(name, color, price, category_id)
                        VALUES (:name, :color, :price, :categoryId)
                        RETURNING id
                        """)
                        .bind("name", name).bind("color", color)
                        .bind("price", price).bind("categoryId", categoryId)
                        .mapTo(Long.class).one();

                h.createUpdate("""
                        INSERT INTO stock(product_id, warehouse_id, quantity)
                        VALUES (:productId, :warehouseId, :quantity)
                        """)
                        .bind("productId", productId).bind("warehouseId", warehouseId)
                        .bind("quantity", quantity).execute();

                h.createUpdate("""
                        INSERT INTO product_supplier(product_id, supplier_id)
                        VALUES (:productId, :supplierId)
                        """)
                        .bind("productId", productId).bind("supplierId", supplierId)
                        .execute();
                h.commit();
                return 1;
            } catch (RuntimeException e) {
                h.rollback();
                throw e;
            }
        }
    }

    // Modificar el catálogo y sustituir la asociación con el proveedor en una sola transacción.
    // La interfaz trabaja con un proveedor principal por producto.
    public int editProduct(Long id, String name, String color, BigDecimal price,
                           Long categoryId, Long supplierId) {
        try (Handle h = jdbi.open()) {
            h.begin();
            try {
                int rows = h.createUpdate("""
                        UPDATE product
                        SET name = :name, color = :color, price = :price,
                            category_id = :categoryId
                        WHERE id = :id
                        """)
                        .bind("id", id).bind("name", name).bind("color", color)
                        .bind("price", price).bind("categoryId", categoryId)
                        .execute();
                if (rows != 1) {
                    h.rollback();
                    return rows;
                }
                h.createUpdate("DELETE FROM product_supplier WHERE product_id = :id")
                        .bind("id", id).execute();
                h.createUpdate("""
                        INSERT INTO product_supplier (product_id, supplier_id)
                        VALUES (:id, :supplierId)
                        """)
                        .bind("id", id).bind("supplierId", supplierId).execute();
                h.commit();
                return rows;
            } catch (RuntimeException e) {
                h.rollback();
                throw e;
            }
        }
    }

    public int deleteProduct(Long id) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("DELETE FROM product WHERE id=:id").bind("id",id).execute();
        }
    }
}
