package com.example.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.jdbi.v3.core.statement.UnableToExecuteStatementException;
import org.springframework.dao.DataIntegrityViolationException;

// Un solo lugar para manejar los errores de los controladores REST.
@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> invalidData(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler({UnableToExecuteStatementException.class,
                       DataIntegrityViolationException.class})
    public ResponseEntity<String> databaseError(Exception e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body("No se pudo guardar o eliminar el registro. Revisá las relaciones y los datos.");
    }
}
