package com.example.demo.controller;

import com.example.demo.model.ProductWithStock;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.StockService;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/inventory")
public class InventoryViewController {
    private final ProductRepository products;
    private final StockService stockService;
    private final Jdbi jdbi;
    public InventoryViewController(ProductRepository products, StockService stockService, Jdbi jdbi) {
        this.products = products;
        this.stockService = stockService;
        this.jdbi = jdbi;
    }

    @GetMapping("/products")
    public List<ProductWithStock> products() { return products.findAllWithStock(); }

    @GetMapping("/stock")
    public List<Map<String, Object>> stock() {
        String sql = """
            SELECT s.product_id AS "productId", s.warehouse_id AS "warehouseId",
                   p.name AS "productName", w.name AS "warehouseName",
                   s.quantity, p.price,
                   s.quantity * p.price AS "totalValue"
            FROM stock s
            INNER JOIN product p ON p.id = s.product_id
            INNER JOIN warehouse w ON w.id = s.warehouse_id
            ORDER BY p.price DESC, p.name ASC, w.name ASC
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).mapToMap().list();
        }
    }

    @GetMapping("/total")
    public BigDecimal total() { return stockService.getTotalStockValue(); }

}
