package com.example.demo.service;

import com.example.demo.model.Stock;
import com.example.demo.repository.StockRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;

@Service
public class StockService {

    private final StockRepository stockRepository;

    public StockService(StockRepository stockRepository) {
        this.stockRepository = stockRepository;
    }

    // Obtener todos los registros
    public List<Stock> getAllStock() {
        return stockRepository.findAll();
    }

    // Buscar por ID
    public Optional<Stock> getStockById(Long id) {
        return stockRepository.findById(id);
    }

    // Crear un registro
    public Stock createStock(Stock stock) {
        return stockRepository.add(stock);
    }

    // Aumentar cantidad
    public int addStock(Long productId, Long warehouseId, Integer quantity) {

        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser positiva");
        }

        return stockRepository.addStock(productId, warehouseId, quantity);
    }

    // Disminuir cantidad
    public int removeStock(Long productId, Long warehouseId, Integer quantity) {

        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser positiva");
        }

        return stockRepository.removeStock(productId, warehouseId, quantity);
    }

    // Eliminar registro
    public int deleteStock(Long id) {
        return stockRepository.delete(id);
    }
    //Valor total 
    public BigDecimal getTotalStockValue(){
        return stockRepository.getTotalStockValue();
    }
}