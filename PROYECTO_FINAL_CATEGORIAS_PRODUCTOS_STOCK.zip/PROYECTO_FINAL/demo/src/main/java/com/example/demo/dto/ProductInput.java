package com.example.demo.dto;

import java.math.BigDecimal;

// Datos que envía el formulario al crear o editar un producto.
// warehouseId y quantity se usan solo al crear el producto.
public class ProductInput {
    private String name;
    private String color;
    private BigDecimal price;
    private Long categoryId;
    private Long warehouseId;
    private Integer quantity;
    private Long supplierId;

    public ProductInput() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }
}
