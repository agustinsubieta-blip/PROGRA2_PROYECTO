package com.example.demo.repository;

import com.example.demo.model.AppUser;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {

    private final Jdbi jdbi;

    public UserRepository(Jdbi jdbi) {
        this.jdbi = jdbi;
    }

    // Obtener todos los usuarios
    public List<AppUser> findAll() {

        String sql = """
            SELECT id,
                   username,
                   password_hash AS "passwordHash",
                   role,
                   enabled
            FROM app_user
            ORDER BY username
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .mapToBean(AppUser.class)
                    .list();
        }
    }

    // Buscar usuario por nombre
    public Optional<AppUser> findByUsername(String username) {

        String sql = """
            SELECT id,
                   username,
                   password_hash AS "passwordHash",
                   role,
                   enabled
            FROM app_user
            WHERE username = :username
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .bind("username", username)
                    .mapToBean(AppUser.class)
                    .findOne();
        }
    }

    // Buscar usuario por ID
    public Optional<AppUser> findById(Long id) {

        String sql = """
            SELECT id,
                   username,
                   password_hash AS "passwordHash",
                   role,
                   enabled
            FROM app_user
            WHERE id = :id
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .bind("id", id)
                    .mapToBean(AppUser.class)
                    .findOne();
        }
    }

    // Crear usuario
    public AppUser add(AppUser user) {

        String sql = """
            INSERT INTO app_user
                (username, password_hash, role, enabled)
            VALUES
                (:username, :passwordHash, :role, :enabled)
            RETURNING id
            """;

        try (Handle handle = jdbi.open()) {

            Long id = handle.createQuery(sql)
                    .bind("username", user.getUsername())
                    .bind("passwordHash", user.getPasswordHash())
                    .bind("role", user.getRole())
                    .bind("enabled", user.isEnabled())
                    .mapTo(Long.class)
                    .one();

            user.setId(id);

            return user;
        }
    }

    // Editar usuario
    public boolean update(AppUser user) {

        String sql = """
            UPDATE app_user
            SET username = :username,
                role = :role,
                enabled = :enabled
            WHERE id = :id
              AND (
                  role <> 'ADMIN'
                  OR (
                      :role = 'ADMIN'
                      AND :enabled = TRUE
                  )
              )
            """;

        try (Handle handle = jdbi.open()) {

            int rows = handle.createUpdate(sql)
                    .bind("id", user.getId())
                    .bind("username", user.getUsername())
                    .bind("role", user.getRole())
                    .bind("enabled", user.isEnabled())
                    .execute();

            return rows == 1;
        }
    }
}