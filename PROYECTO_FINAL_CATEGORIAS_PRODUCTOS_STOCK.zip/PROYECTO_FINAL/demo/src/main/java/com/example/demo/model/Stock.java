package com.example.demo.model;

public class Stock {

    private Long id;
    private Long productId;
    private Long warehouseId;
    private Integer quantity;

    // Constructor vacío para Jdbi
    public Stock() {
    }

    // Constructor con todos los atributos
    public Stock(Long id, Long productId, Long warehouseId, Integer quantity) {
        this.id = id;
        this.productId = productId;
        this.warehouseId = warehouseId;
        this.quantity = quantity;
    }

    // Getters y setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Long warehouseId) {
        this.warehouseId = warehouseId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}