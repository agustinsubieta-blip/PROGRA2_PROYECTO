package com.example.demo.service;

import com.example.demo.model.AppUser;
import com.example.demo.repository.UserRepository;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Obtener todos los usuarios
    public List<AppUser> getAllUsers() {
        return userRepository.findAll();
    }

    // Buscar usuario por ID
    public AppUser getUserById(Long id) {

        Optional<AppUser> result = userRepository.findById(id);

        if (result.isEmpty()) {
            throw new IllegalArgumentException(
                    "Usuario no encontrado"
            );
        }

        return result.get();
    }

    // Crear usuario
    public AppUser createUser(
            String username,
            String password,
            String role) {

        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre de usuario es obligatorio"
            );
        }

        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException(
                    "La contraseña es obligatoria"
            );
        }

        if (!isValidRole(role)) {
            throw new IllegalArgumentException(
                    "El rol no es válido"
            );
        }

        username = username.trim();

        if (userRepository.findByUsername(username).isPresent()) {
            throw new IllegalArgumentException(
                    "El nombre de usuario ya existe"
            );
        }

        AppUser user = new AppUser();

        user.setUsername(username);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setRole(role);
        user.setEnabled(true);

        return userRepository.add(user);
    }

    // Validar roles
    private boolean isValidRole(String role) {

        return "ADMIN".equals(role)
                || "EMPLOYEE".equals(role)
                || "VIEWER".equals(role);
    }

    // Editar usuario
    public void updateUser(
            Long id,
            String username,
            String role,
            boolean enabled,
            String currentUsername) {

        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre de usuario es obligatorio"
            );
        }

        if (!isValidRole(role)) {
            throw new IllegalArgumentException(
                    "El rol no es válido"
            );
        }

        username = username.trim();

        if (username.length() > 50) {
            throw new IllegalArgumentException(
                    "El nombre no puede superar los 50 caracteres"
            );
        }

        AppUser user = getUserById(id);

        // Proteger las cuentas ADMIN
        if ("ADMIN".equals(user.getRole())) {

            if (!"ADMIN".equals(role) || !enabled) {
                throw new IllegalArgumentException(
                        "No se puede cambiar el rol ni " +
                        "deshabilitar una cuenta ADMIN"
                );
            }
        }

        // Proteger la cuenta del usuario que realiza la edición
        if (user.getUsername().equals(currentUsername)) {

            if (!"ADMIN".equals(role) || !enabled) {
                throw new IllegalArgumentException(
                        "No podés quitarte el rol ADMIN " +
                        "ni deshabilitar tu propia cuenta"
                );
            }
        }

        // Comprobar que el nuevo nombre no pertenezca a otro usuario
        Optional<AppUser> existing =
                userRepository.findByUsername(username);

        if (existing.isPresent()) {

            if (!existing.get().getId().equals(id)) {
                throw new IllegalArgumentException(
                        "El nombre de usuario ya está en uso"
                );
            }
        }

        // Asignar nuevos valores
        user.setUsername(username);
        user.setRole(role);
        user.setEnabled(enabled);

        // Guardar cambios
        boolean updated = userRepository.update(user);

        if (!updated) {
            throw new IllegalArgumentException(
                    "No se pudieron guardar los cambios"
            );
        }
    }
}