package com.example.demo.repository;

import com.example.demo.model.Stock;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;

import java.util.List;
import java.util.Optional;

@Repository
public class StockRepository {

    private final Jdbi jdbi;

    public StockRepository(Jdbi jdbi) {
        this.jdbi = jdbi;
    }

    // Obtener todos los registros de stock
    public List<Stock> findAll() {

        String sql = """
            SELECT
                id,
                product_id AS "productId",
                warehouse_id AS "warehouseId",
                quantity
            FROM stock
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .mapToBean(Stock.class)
                    .list();
        }
    }

    // Buscar stock por ID
    public Optional<Stock> findById(Long id) {

        String sql = """
            SELECT
                id,
                product_id AS "productId",
                warehouse_id AS "warehouseId",
                quantity
            FROM stock
            WHERE id = :id
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .bind("id", id)
                    .mapToBean(Stock.class)
                    .findOne();
        }
    }

    // Crear un registro de stock
    public Stock add(Stock stock) {

        String sql = """
            INSERT INTO stock (
                product_id,
                warehouse_id,
                quantity
            )
            VALUES (
                :productId,
                :warehouseId,
                :quantity
            )
            RETURNING id
            """;

        try (Handle handle = jdbi.open()) {

            Long id = handle.createQuery(sql)
                    .bind("productId", stock.getProductId())
                    .bind("warehouseId", stock.getWarehouseId())
                    .bind("quantity", stock.getQuantity())
                    .mapTo(Long.class)
                    .one();

            stock.setId(id);

            return stock;
        }
    }

    // Crear la existencia si el producto todavía no está en ese almacén;
    // de lo contrario, sumar unidades a la existencia existente.
    // Requiere UNIQUE (product_id, warehouse_id), incluida en migracion_warehouse.sql.
    public int addStock(Long productId, Long warehouseId, Integer quantity) {
        String sql = """
            INSERT INTO stock(product_id, warehouse_id, quantity)
            VALUES (:productId, :warehouseId, :quantity)
            ON CONFLICT (product_id, warehouse_id)
            DO UPDATE SET quantity = stock.quantity + EXCLUDED.quantity
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createUpdate(sql)
                    .bind("productId", productId)
                    .bind("warehouseId", warehouseId)
                    .bind("quantity", quantity)
                    .execute();
        }
    }

    // Disminuir la cantidad de stock
    public int removeStock(
            Long productId,
            Long warehouseId,
            Integer quantity) {

        String sql = """
            UPDATE stock
            SET quantity = quantity - :quantity
            WHERE product_id = :productId
              AND warehouse_id = :warehouseId
              AND quantity >= :quantity
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createUpdate(sql)
                    .bind("productId", productId)
                    .bind("warehouseId", warehouseId)
                    .bind("quantity", quantity)
                    .execute();
        }
    }

    // Eliminar un registro de stock
    public int delete(Long id) {

        String sql = "DELETE FROM stock WHERE id = :id";

        try (Handle handle = jdbi.open()) {

            return handle.createUpdate(sql)
                    .bind("id", id)
                    .execute();
        }
    }
    public BigDecimal getTotalStockValue() {

    String sql = """
        SELECT COALESCE(SUM(s.quantity * p.price), 0)
        FROM stock s
        INNER JOIN product p
            ON s.product_id = p.id
        """;

    try (Handle handle = jdbi.open()) {

        return handle.createQuery(sql)
                .mapTo(BigDecimal.class)
                .one();
    }
    }
    // Datos de stock para la pantalla de consulta, ordenados por precio.
    public List<java.util.Map<String, Object>> findStockDetails() {
        String sql = """
            SELECT s.product_id AS "productId", s.warehouse_id AS "warehouseId",
                   p.name AS "productName", w.name AS "warehouseName",
                   s.quantity, p.price,
                   s.quantity * p.price AS "totalValue"
            FROM stock s
            INNER JOIN product p ON p.id = s.product_id
            INNER JOIN warehouse w ON w.id = s.warehouse_id
            ORDER BY p.price DESC, p.name ASC, w.name ASC
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).mapToMap().list();
        }
    }
}