package com.example.demo.repository;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class WarehouseRepository extends BaseRepository<Warehouse> {

    public WarehouseRepository(Jdbi jdbi) {
        super(jdbi, Warehouse.class, "warehouse");
    }

    // Obtener categorías de un almacén
    public List<Category> findCategoriesByWarehouse(Long warehouseId) {

        String sql = """
            SELECT DISTINCT c.id, c.name
            FROM category c
            INNER JOIN product p
                ON p.category_id = c.id
            INNER JOIN stock s
                ON s.product_id = p.id
            WHERE s.warehouse_id = :warehouseId
            ORDER BY c.name
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .bind("warehouseId", warehouseId)
                    .mapToBean(Category.class)
                    .list();
        }
    }

    // Obtener productos de una categoría en un almacén
    public List<ProductWithStock> findProductsByWarehouseAndCategory(
            Long warehouseId,
            Long categoryId) {

        String sql = """
            SELECT
                p.id,
                p.name,
                p.color,
                p.price,
                p.category_id AS "categoryId",
                (SELECT MIN(ps.supplier_id)
                 FROM product_supplier ps
                 WHERE ps.product_id = p.id) AS "supplierId",
                (SELECT STRING_AGG(DISTINCT sp.name, ', ' ORDER BY sp.name)
                 FROM product_supplier ps
                 JOIN supplier sp ON sp.id = ps.supplier_id
                 WHERE ps.product_id = p.id) AS "supplierName",
                SUM(s.quantity) AS quantity
            FROM product p
            INNER JOIN stock s
                ON s.product_id = p.id
            WHERE s.warehouse_id = :warehouseId
              AND p.category_id = :categoryId
            GROUP BY
                p.id,
                p.name,
                p.color,
                p.price,
                p.category_id,
                s.warehouse_id
            ORDER BY p.name
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createQuery(sql)
                    .bind("warehouseId", warehouseId)
                    .bind("categoryId", categoryId)
                    .mapToBean(ProductWithStock.class)
                    .list();
        }
    }
}