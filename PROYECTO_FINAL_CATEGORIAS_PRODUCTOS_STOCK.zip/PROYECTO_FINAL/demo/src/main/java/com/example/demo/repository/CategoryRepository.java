package com.example.demo.repository;

import com.example.demo.model.Category;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Repository;


@Repository
public class CategoryRepository extends BaseRepository<Category> {

    public CategoryRepository(Jdbi jdbi) {
        super(jdbi, Category.class, "category");
    }

    public Category save(Category category) {

        String sql = """
            INSERT INTO category (name)
            VALUES (:name)
            RETURNING id
            """;

        try (Handle handle = jdbi.open()) {

            Long id = handle.createQuery(sql)
                    .bind("name", category.getName())
                    .mapTo(Long.class)
                    .one();

            category.setId(id);

            return category;
        }
    }
}