package com.example.demo.service;

import com.example.demo.repository.InventoryCrudRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class InventoryCrudService {
    private final InventoryCrudRepository repository;
    public InventoryCrudService(InventoryCrudRepository repository) { this.repository = repository; }

    private String required(String value, String field, int max) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " es obligatorio");
        String result = value.trim();
        if (result.length() > max) throw new IllegalArgumentException(field + " no puede superar " + max + " caracteres");
        return result;
    }
    private Long requiredId(Long value, String field) {
        if (value == null || value < 1) throw new IllegalArgumentException("Seleccioná " + field);
        return value;
    }
    private BigDecimal validPrice(BigDecimal price) {
        if (price == null || price.signum() < 0 || price.scale() > 2 || price.compareTo(new BigDecimal("99999999.99")) > 0)
            throw new IllegalArgumentException("El precio debe estar entre 0 y 99999999.99 y tener máximo dos decimales");
        return price;
    }
    public void saveCategory(Long id, String name) {
        String n = required(name,"El nombre",80);
        int rows = id == null ? repository.createCategory(n) : repository.editCategory(id,n);
        check(rows);
    }
    public void deleteCategory(Long id) { check(repository.deleteCategory(requiredId(id,"una categoría"))); }
    public void saveSupplier(Long id, String name, String location) {
        String n=required(name,"El nombre",100), l=required(location,"La ubicación",100);
        check(id==null ? repository.createSupplier(n,l) : repository.editSupplier(id,n,l));
    }
    public void deleteSupplier(Long id) { check(repository.deleteSupplier(requiredId(id,"un proveedor"))); }
    public void saveWarehouse(Long id, String name, String location) {
        String n=required(name,"El nombre",100), l=required(location,"La ubicación",500);
        check(id==null ? repository.createWarehouse(n,l) : repository.editWarehouse(id,n,l));
    }
    public void deleteWarehouse(Long id) { check(repository.deleteWarehouse(requiredId(id,"un almacén"))); }
    public void createProduct(String name, String color, BigDecimal price,
                              Long categoryId, Long warehouseId, Integer quantity,
                              Long supplierId) {
        String n = required(name, "El nombre", 100);
        String c = required(color, "El color", 100);
        requiredId(categoryId, "una categoría");
        requiredId(warehouseId, "un almacén");
        requiredId(supplierId, "un proveedor");
        if (quantity == null || quantity < 0) {
            throw new IllegalArgumentException("El stock inicial no puede ser negativo");
        }
        check(repository.createProduct(n, c, validPrice(price), categoryId,
                                       warehouseId, quantity, supplierId));
    }

    public void saveProduct(Long id, String name, String color, BigDecimal price, Long categoryId, Long supplierId) {
        String n=required(name,"El nombre",100), c=required(color,"El color",100);
        requiredId(categoryId,"una categoría");
        if (id == null) throw new IllegalArgumentException("Usá createProduct para insertar productos con stock y proveedor");
        requiredId(supplierId, "un proveedor");
        check(repository.editProduct(id,n,c,validPrice(price),categoryId,supplierId));
    }
    public void deleteProduct(Long id) { check(repository.deleteProduct(requiredId(id,"un producto"))); }
    private void check(int rows) {
        if (rows != 1) throw new IllegalArgumentException("No se encontró el registro que querés modificar");
    }
}
