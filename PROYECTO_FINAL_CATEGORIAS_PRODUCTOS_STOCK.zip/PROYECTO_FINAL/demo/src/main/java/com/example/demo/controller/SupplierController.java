package com.example.demo.controller;

import com.example.demo.model.Supplier;
import com.example.demo.service.SupplierService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class SupplierController {
    private final SupplierService supplierService;

    public SupplierController(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    @GetMapping("/suppliers")
    public List<Supplier> listSuppliers() {
        return supplierService.getAllSuppliers();
    }

    @PostMapping("/suppliers")
    public boolean addSupplier(@RequestBody Supplier supplier) {
        supplierService.saveSupplier(null, supplier.getName(), supplier.getLocation());
        return true;
    }

    @PutMapping("/suppliers/{id}")
    public boolean editSupplier(@PathVariable Long id, @RequestBody Supplier supplier) {
        supplierService.saveSupplier(id, supplier.getName(), supplier.getLocation());
        return true;
    }

    @DeleteMapping("/suppliers/{id}")
    public boolean removeSupplier(@PathVariable Long id) {
        supplierService.deleteSupplier(id);
        return true;
    }
}
