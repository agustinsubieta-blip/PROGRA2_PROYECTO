package com.example.demo.service;

import com.example.demo.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;
import com.example.demo.model.ProductWithStock;

@Service
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductWithStock> getAllProductsWithStock() {
        return productRepository.findAllWithStock();
    }

    public void createProduct(String name, String color, BigDecimal price,
                              Long categoryId, Long warehouseId, Integer quantity,
                              Long supplierId) {
        String cleanName = InventoryValidation.required(name, "El nombre", 100);
        String cleanColor = InventoryValidation.required(color, "El color", 100);
        InventoryValidation.requiredId(categoryId, "una categoría");
        InventoryValidation.requiredId(warehouseId, "un almacén");
        InventoryValidation.requiredId(supplierId, "un proveedor");
        if (quantity == null || quantity < 0) {
            throw new IllegalArgumentException("El stock inicial no puede ser negativo");
        }
        InventoryValidation.check(productRepository.createProduct(
                cleanName, cleanColor, InventoryValidation.validPrice(price),
                categoryId, warehouseId, quantity, supplierId));
    }

    public void saveProduct(Long id, String name, String color, BigDecimal price,
                            Long categoryId, Long supplierId) {
        InventoryValidation.requiredId(id, "un producto");
        String cleanName = InventoryValidation.required(name, "El nombre", 100);
        String cleanColor = InventoryValidation.required(color, "El color", 100);
        InventoryValidation.requiredId(categoryId, "una categoría");
        InventoryValidation.requiredId(supplierId, "un proveedor");
        InventoryValidation.check(productRepository.editProduct(
                id, cleanName, cleanColor, InventoryValidation.validPrice(price),
                categoryId, supplierId));
    }

    public void deleteProduct(Long id) {
        InventoryValidation.check(productRepository.deleteProduct(
                InventoryValidation.requiredId(id, "un producto")));
    }
}
