package com.example.demo.repository;

import com.example.demo.model.Supplier;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Repository;

@Repository
public class SupplierRepository extends BaseRepository<Supplier> {

    public SupplierRepository(Jdbi jdbi) {
        super(jdbi, Supplier.class, "supplier");
    }

    // Agregar proveedor
    public Supplier add(Supplier supplier) {

        String sql = """
            INSERT INTO supplier (name, location)
            VALUES (:name, :location)
            RETURNING id
            """;

        try (Handle handle = jdbi.open()) {

            Long id = handle.createQuery(sql)
                    .bind("name", supplier.getName())
                    .bind("location", supplier.getLocation())
                    .mapTo(Long.class)
                    .one();

            supplier.setId(id);

            return supplier;
        }
    }

    // Actualizar proveedor
    public int update(Supplier supplier) {

        String sql = """
            UPDATE supplier
            SET name = :name,
                location = :location
            WHERE id = :id
            """;

        try (Handle handle = jdbi.open()) {

            return handle.createUpdate(sql)
                    .bind("id", supplier.getId())
                    .bind("name", supplier.getName())
                    .bind("location", supplier.getLocation())
                    .execute();
        }
    }
}