package com.example.demo.controller;

import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.service.CategoryService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class CategoryController {
    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping("/categories")
    public List<Category> listCategories() {
        return categoryService.getAllCategories();
    }

    @GetMapping("/categories/{id}/products")
    public List<ProductWithStock> getProductsByCategory(@PathVariable Long id) {
        categoryService.getCategoryById(id);
        return categoryService.getProductsByCategory(id);
    }

    @PostMapping("/categories")
    public boolean addCategory(@RequestBody Category category) {
        categoryService.saveCategory(null, category.getName());
        return true;
    }

    @PutMapping("/categories/{id}")
    public boolean editCategory(@PathVariable Long id, @RequestBody Category category) {
        categoryService.saveCategory(id, category.getName());
        return true;
    }

    @DeleteMapping("/categories/{id}")
    public boolean removeCategory(@PathVariable Long id) {
        categoryService.deleteCategory(id);
        return true;
    }
}
