package com.example.demo.controller;

import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.service.CategoryService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/categories")
public class CategoryController {
    private final CategoryService categoryService;
    public CategoryController(CategoryService categoryService) { this.categoryService = categoryService; }

    @GetMapping
    public List<Category> listCategories() { return categoryService.getAllCategories(); }

    @GetMapping("/{id}/products")
    public List<ProductWithStock> getProductsByCategory(@PathVariable Long id) {
        categoryService.getCategoryById(id);
        return categoryService.getProductsByCategory(id);
    }

    @PostMapping
    public Category createCategory(@RequestBody Category category) {
        return categoryService.createCategory(category.getName());
    }
}
