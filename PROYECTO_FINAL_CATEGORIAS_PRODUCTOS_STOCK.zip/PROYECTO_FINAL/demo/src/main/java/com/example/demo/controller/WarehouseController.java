package com.example.demo.controller;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.service.WarehouseService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class WarehouseController {
    private final WarehouseService warehouseService;

    public WarehouseController(WarehouseService warehouseService) {
        this.warehouseService = warehouseService;
    }

    @GetMapping("/warehouses")
    public List<Warehouse> getAllWarehouses() {
        return warehouseService.getAllWarehouses();
    }

    @GetMapping("/warehouses/{id}/categories")
    public List<Category> getCategoriesByWarehouse(@PathVariable Long id) {
        return warehouseService.getCategoriesByWarehouse(id);
    }

    @GetMapping("/warehouses/{warehouseId}/categories/{categoryId}/products")
    public List<ProductWithStock> getProducts(
            @PathVariable Long warehouseId, @PathVariable Long categoryId) {
        return warehouseService.getProductsByWarehouseAndCategory(warehouseId, categoryId);
    }

    @PostMapping("/warehouses")
    public boolean addWarehouse(@RequestBody Warehouse warehouse) {
        warehouseService.saveWarehouse(null, warehouse.getName(), warehouse.getLocation());
        return true;
    }

    @PutMapping("/warehouses/{id}")
    public boolean editWarehouse(@PathVariable Long id, @RequestBody Warehouse warehouse) {
        warehouseService.saveWarehouse(id, warehouse.getName(), warehouse.getLocation());
        return true;
    }

    @DeleteMapping("/warehouses/{id}")
    public boolean removeWarehouse(@PathVariable Long id) {
        warehouseService.deleteWarehouse(id);
        return true;
    }
}
