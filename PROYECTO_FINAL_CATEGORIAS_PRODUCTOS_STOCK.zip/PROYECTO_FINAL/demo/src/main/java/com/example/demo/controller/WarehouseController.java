package com.example.demo.controller;

import com.example.demo.model.Warehouse;
import com.example.demo.model.Category;
import com.example.demo.model.ProductWithStock;
import com.example.demo.service.WarehouseService;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/warehouses")
public class WarehouseController {

    private final WarehouseService warehouseService;

    public WarehouseController(WarehouseService warehouseService) {
        this.warehouseService = warehouseService;
    }

    @GetMapping
    public List<Warehouse> getAllWarehouses() {
        return warehouseService.getAllWarehouses();
    }

    @GetMapping("/{id}/categories")
    public List<Category> getCategoriesByWarehouse(@PathVariable Long id) {
        return warehouseService.getCategoriesByWarehouse(id);
    }

    @GetMapping("/{warehouseId}/categories/{categoryId}/products")
    public List<ProductWithStock> getProducts(
            @PathVariable Long warehouseId,
            @PathVariable Long categoryId) {

        return warehouseService.getProductsByWarehouseAndCategory(
                warehouseId, categoryId
        );
    }
}