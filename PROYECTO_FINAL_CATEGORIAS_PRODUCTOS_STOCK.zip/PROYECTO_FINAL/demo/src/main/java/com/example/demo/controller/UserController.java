package com.example.demo.controller;

import com.example.demo.model.AppUser;
import com.example.demo.service.UserService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Mostrar todos los usuarios
    @GetMapping
    public String listUsers(Model model) {

        model.addAttribute("users", userService.getAllUsers());

        return "users";
    }

    // Mostrar formulario de creación
    @GetMapping("/new")
    public String showCreateUser() {

        return "create-user";
    }

    // Crear usuario
    @PostMapping
    public String createUser(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String role,
            RedirectAttributes redirectAttributes) {

        try {

            userService.createUser(username, password, role);

            redirectAttributes.addFlashAttribute(
                    "success",
                    "Usuario creado correctamente");

            return "redirect:/users";

        } catch (IllegalArgumentException e) {

            redirectAttributes.addFlashAttribute(
                    "error",
                    e.getMessage());

            return "redirect:/users/new";
        }
    }

    // Mostrar formulario de edición
    @GetMapping("/{id}/edit")
    public String showEditUser(
            @PathVariable Long id,
            Model model,
            RedirectAttributes redirectAttributes) {

        try {

            AppUser user = userService.getUserById(id);

            model.addAttribute("user", user);

            return "edit-user";

        } catch (IllegalArgumentException e) {

            redirectAttributes.addFlashAttribute(
                    "error",
                    e.getMessage());

            return "redirect:/users";
        }
    }

    // Guardar cambios de usuario
    @PostMapping("/{id}/edit")
    public String updateUser(
            @PathVariable Long id,
            @RequestParam String username,
            @RequestParam String role,
            @RequestParam boolean enabled,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {

        try {

            userService.updateUser(
                    id,
                    username,
                    role,
                    enabled,
                    authentication.getName());

            redirectAttributes.addFlashAttribute(
                    "success",
                    "Usuario actualizado correctamente");

            return "redirect:/users";

        } catch (IllegalArgumentException e) {

            redirectAttributes.addFlashAttribute(
                    "error",
                    e.getMessage());

            return "redirect:/users/" + id + "/edit";
        }
    }
}