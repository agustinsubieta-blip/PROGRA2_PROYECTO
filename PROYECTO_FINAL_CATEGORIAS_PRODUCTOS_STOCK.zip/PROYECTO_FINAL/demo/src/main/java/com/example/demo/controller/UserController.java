package com.example.demo.controller;

import com.example.demo.model.AppUser;
import com.example.demo.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public String listUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "users";
    }

    @GetMapping("/new")
    public String showCreateUser() {
        return "create-user";
    }

    @PostMapping
    public String createUser(@RequestParam String username,
                             @RequestParam String password,
                             @RequestParam String role, Model model) {
        try {
            userService.createUser(username, password, role);
            return "redirect:/users?created";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "create-user";
        }
    }

    @GetMapping("/{id}/edit")
    public String showEditUser(@PathVariable Long id, Model model) {
        model.addAttribute("user", userService.getUserById(id));
        return "edit-user";
    }

    @PostMapping("/{id}/edit")
    public String updateUser(@PathVariable Long id,
                             @RequestParam String username,
                             @RequestParam String role,
                             @RequestParam boolean enabled,
                             Authentication authentication,
                             Model model) {
        try {
            userService.updateUser(id, username, role, enabled, authentication.getName());
            return "redirect:/users?updated";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("user", userService.getUserById(id));
            return "edit-user";
        }
    }
}
