package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
            .authorizeHttpRequests(auth -> auth

                // Recursos públicos
                .requestMatchers(
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/error"
                ).permitAll()

                // Administración de usuarios
                .requestMatchers(
                    "/users",
                    "/users/**"
                ).hasRole("ADMIN")

                // Gestión del inventario: edición para ADMIN y EMPLOYEE; eliminación para ADMIN.
                .requestMatchers(HttpMethod.DELETE, "/api/manage/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/manage/**").hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.PUT, "/api/manage/**").hasAnyRole("ADMIN", "EMPLOYEE")

                // Crear y modificar productos y stock
                .requestMatchers(
                    HttpMethod.POST,
                    "/products", "/products/**",
                    "/stock", "/stock/**"
                ).hasAnyRole("ADMIN", "EMPLOYEE")

                .requestMatchers(
                    HttpMethod.PUT,
                    "/products", "/products/**",
                    "/stock", "/stock/**"
                ).hasAnyRole("ADMIN", "EMPLOYEE")

                .requestMatchers(
                    HttpMethod.PATCH,
                    "/products", "/products/**",
                    "/stock", "/stock/**"
                ).hasAnyRole("ADMIN", "EMPLOYEE")


                // Consultar información
                .requestMatchers(HttpMethod.GET, "/**")
                    .authenticated()

                // Otras operaciones: solo administrador
                .anyRequest().hasRole("ADMIN")
            )

            // Activar el formulario de inicio de sesión
            .formLogin(form -> form
            .loginPage("/login")
            .defaultSuccessUrl("/", true)
            .permitAll()
            )

            // Activar cierre de sesión
            .logout(withDefaults());

        return http.build();
    }
}