package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
            .authorizeHttpRequests(auth -> auth

                // Recursos públicos
                .requestMatchers(
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/error"
                ).permitAll()

                // Administración de usuarios
                .requestMatchers(
                    "/users",
                    "/users/**"
                ).hasRole("ADMIN")

                // Las operaciones de eliminación están reservadas a ADMIN.
                .requestMatchers(HttpMethod.DELETE,
                    "/categories/**", "/products/**", "/warehouses/**", "/suppliers/**")
                    .hasRole("ADMIN")

                // ADMIN y EMPLOYEE pueden crear o editar registros.
                .requestMatchers(HttpMethod.POST,
                    "/categories", "/products", "/warehouses", "/suppliers")
                    .hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.PUT,
                    "/categories/**", "/products/**", "/warehouses/**", "/suppliers/**")
                    .hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.PATCH,
                    "/categories/**", "/products/**", "/warehouses/**", "/suppliers/**")
                    .hasAnyRole("ADMIN", "EMPLOYEE")

                // Si en el futuro se habilitan ajustes de stock, protegerlos.
                .requestMatchers(HttpMethod.POST, "/stock", "/stock/**")
                    .hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.PUT, "/stock", "/stock/**")
                    .hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.PATCH, "/stock", "/stock/**")
                    .hasAnyRole("ADMIN", "EMPLOYEE")
                .requestMatchers(HttpMethod.DELETE, "/stock", "/stock/**")
                    .hasRole("ADMIN")

                // Consultar información
                .requestMatchers(HttpMethod.GET, "/**")
                    .authenticated()

                // Otras operaciones: solo administrador
                .anyRequest().hasRole("ADMIN")
            )

            // Activar el formulario de inicio de sesión
            .formLogin(form -> form
            .loginPage("/login")
            .defaultSuccessUrl("/", true)
            .permitAll()
            )

            // Activar cierre de sesión
            .logout(withDefaults());

        return http.build();
    }
}