package com.example.demo.repository;

import com.example.demo.model.ProductWithStock;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;

@Repository
public class ProductRepository {
    private final Jdbi jdbi;
    public ProductRepository(Jdbi jdbi) { this.jdbi = jdbi; }

    // El stock se suma entre almacenes, no se depende de product.warehouse_id.
    private static final String BASE_SQL = """
        SELECT p.id, p.name, p.color, p.price,
               p.category_id AS "categoryId",
               (SELECT MIN(ps.supplier_id)
                FROM product_supplier ps
                WHERE ps.product_id = p.id) AS "supplierId",
               (SELECT STRING_AGG(DISTINCT sp.name, ', ' ORDER BY sp.name)
                FROM product_supplier ps
                JOIN supplier sp ON sp.id = ps.supplier_id
                WHERE ps.product_id = p.id) AS "supplierName",
               COALESCE(SUM(s.quantity), 0) AS quantity
        FROM product p
        LEFT JOIN stock s ON s.product_id = p.id
        """;

    public List<ProductWithStock> findAllWithStock() {
        String sql = BASE_SQL + """
            GROUP BY p.id, p.name, p.color, p.price, p.category_id
            ORDER BY p.name
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).mapToBean(ProductWithStock.class).list();
        }
    }

    public List<ProductWithStock> findByCategoryWithStock(Long categoryId) {
        String sql = BASE_SQL + """
            WHERE p.category_id = :categoryId
            GROUP BY p.id, p.name, p.color, p.price, p.category_id
            ORDER BY p.name
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).bind("categoryId", categoryId)
                    .mapToBean(ProductWithStock.class).list();
        }
    }

    // Operaciones de escritura de Product.
    public int createProduct(String name, String color, BigDecimal price,
                             Long categoryId, Long warehouseId, Integer quantity,
                             Long supplierId) {
        try (Handle h = jdbi.open()) {
            h.begin();
            try {
                Long productId = h.createQuery("""
                        INSERT INTO product(name, color, price, category_id)
                        VALUES (:name, :color, :price, :categoryId)
                        RETURNING id
                        """)
                        .bind("name", name).bind("color", color)
                        .bind("price", price).bind("categoryId", categoryId)
                        .mapTo(Long.class).one();

                h.createUpdate("""
                        INSERT INTO stock(product_id, warehouse_id, quantity)
                        VALUES (:productId, :warehouseId, :quantity)
                        """)
                        .bind("productId", productId).bind("warehouseId", warehouseId)
                        .bind("quantity", quantity).execute();

                h.createUpdate("""
                        INSERT INTO product_supplier(product_id, supplier_id)
                        VALUES (:productId, :supplierId)
                        """)
                        .bind("productId", productId).bind("supplierId", supplierId)
                        .execute();
                h.commit();
                return 1;
            } catch (RuntimeException e) {
                h.rollback();
                throw e;
            }
        }
    }

    public int editProduct(Long id, String name, String color, BigDecimal price,
                           Long categoryId, Long supplierId) {
        try (Handle h = jdbi.open()) {
            h.begin();
            try {
                int rows = h.createUpdate("""
                        UPDATE product
                        SET name = :name, color = :color, price = :price,
                            category_id = :categoryId
                        WHERE id = :id
                        """)
                        .bind("id", id).bind("name", name).bind("color", color)
                        .bind("price", price).bind("categoryId", categoryId)
                        .execute();
                if (rows != 1) {
                    h.rollback();
                    return rows;
                }
                h.createUpdate("DELETE FROM product_supplier WHERE product_id = :id")
                        .bind("id", id).execute();
                h.createUpdate("""
                        INSERT INTO product_supplier (product_id, supplier_id)
                        VALUES (:id, :supplierId)
                        """)
                        .bind("id", id).bind("supplierId", supplierId).execute();
                h.commit();
                return rows;
            } catch (RuntimeException e) {
                h.rollback();
                throw e;
            }
        }
    }

    public int deleteProduct(Long id) {
        try (Handle h = jdbi.open()) {
            return h.createUpdate("DELETE FROM product WHERE id=:id").bind("id",id).execute();
        }
    }
}
