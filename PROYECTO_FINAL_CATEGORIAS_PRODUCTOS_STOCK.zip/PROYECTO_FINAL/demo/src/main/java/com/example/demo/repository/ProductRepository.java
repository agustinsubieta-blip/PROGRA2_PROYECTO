package com.example.demo.repository;

import com.example.demo.model.ProductWithStock;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ProductRepository {
    private final Jdbi jdbi;
    public ProductRepository(Jdbi jdbi) { this.jdbi = jdbi; }

    // El stock se suma entre almacenes, no se depende de product.warehouse_id.
    private static final String BASE_SQL = """
        SELECT p.id, p.name, p.color, p.price,
               p.category_id AS "categoryId",
               (SELECT MIN(ps.supplier_id)
                FROM product_supplier ps
                WHERE ps.product_id = p.id) AS "supplierId",
               (SELECT STRING_AGG(DISTINCT sp.name, ', ' ORDER BY sp.name)
                FROM product_supplier ps
                JOIN supplier sp ON sp.id = ps.supplier_id
                WHERE ps.product_id = p.id) AS "supplierName",
               COALESCE(SUM(s.quantity), 0) AS quantity
        FROM product p
        LEFT JOIN stock s ON s.product_id = p.id
        """;

    public List<ProductWithStock> findAllWithStock() {
        String sql = BASE_SQL + """
            GROUP BY p.id, p.name, p.color, p.price, p.category_id
            ORDER BY p.name
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).mapToBean(ProductWithStock.class).list();
        }
    }

    public List<ProductWithStock> findByCategoryWithStock(Long categoryId) {
        String sql = BASE_SQL + """
            WHERE p.category_id = :categoryId
            GROUP BY p.id, p.name, p.color, p.price, p.category_id
            ORDER BY p.name
            """;
        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql).bind("categoryId", categoryId)
                    .mapToBean(ProductWithStock.class).list();
        }
    }
}
