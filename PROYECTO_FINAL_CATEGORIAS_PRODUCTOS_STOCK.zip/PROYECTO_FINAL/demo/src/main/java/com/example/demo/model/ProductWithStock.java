package com.example.demo.model;

import java.math.BigDecimal;

public class ProductWithStock extends Product {
    private Long quantity;
    private Long supplierId;
    private String supplierName;

    public ProductWithStock() { super(); }

    public ProductWithStock(Long id, String name, String color,
                            BigDecimal price, Long categoryId, Long quantity) {
        super(id, name, color, price, categoryId);
        this.quantity = quantity;
    }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }
    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }

    public Long getQuantity() { return quantity; }
    public void setQuantity(Long quantity) { this.quantity = quantity; }
}
