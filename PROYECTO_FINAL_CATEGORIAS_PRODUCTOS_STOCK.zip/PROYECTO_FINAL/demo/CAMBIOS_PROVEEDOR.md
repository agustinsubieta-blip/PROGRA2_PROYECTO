# Cambios de proveedor en productos

- En Categorías > Ver más aparece la columna Proveedor (sin mostrar ID).
- Al editar un producto se muestra su proveedor actual y se puede elegir otro.
- Se actualiza `product_supplier` en la misma transacción que `product`.
- Se mantiene la selección de proveedor al crear un producto.
- Si un producto ya tiene varios proveedores, se muestran todos sus nombres, pero el formulario selecciona el proveedor de menor ID y al guardar deja solo el proveedor seleccionado. Esto es intencional para esta interfaz de proveedor único.
- No se necesitan modificaciones SQL: utiliza las tablas `supplier` y `product_supplier` existentes.
- Se corrigieron los nombres de propiedades para el detalle de Stock al usar mapToMap.

Requiere probarse con la base de datos PostgreSQL local.
