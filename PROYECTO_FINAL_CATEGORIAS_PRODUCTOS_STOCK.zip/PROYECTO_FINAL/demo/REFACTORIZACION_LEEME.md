# Refactorización de CRUD por entidad

Se eliminan las tres clases `InventoryCrudController`, `InventoryCrudService` y `InventoryCrudRepository`.

- `CategoryController` → `CategoryService` → `CategoryRepository`
- `ProductController` → `ProductService` → `ProductRepository`
- `SupplierController` → `SupplierService` → `SupplierRepository`
- `WarehouseController` → `WarehouseService` → `WarehouseRepository`

Las consultas de lectura siguen en los repositorios respectivos; `InventoryViewController` sigue dando la vista JSON agregada del inventario.

`ProductInput` es una clase Java normal (`dto/ProductInput.java`) con constructor vacío y getters/setters, sin `record`.

Se reemplazaron los `Map.of("success", true)` por `return true`, que Spring serializa como JSON `true`. Se mantienen las mismas rutas `/api/manage/...` para que el frontend siga conectado y las reglas de seguridad funcionen. `dashboard.js` interpreta JSON cuando hay éxito y mensajes de texto cuando hay errores.

Los errores del CRUD están concentrados en el sencillo `ApiExceptionHandler`; no hay manejadores duplicados por controlador. Los formularios de usuarios ya no dependen de `RedirectAttributes`: errores usando `Model`, éxitos mediante redirección con `?created` o `?updated`.

Se conservan las transacciones del repositorio de productos: producto + stock + proveedor se insertan juntos, y cambio de producto + proveedor se confirma juntos. No requiere migración de base de datos.

## Comprobaciones

- La sintaxis de `static/js/dashboard.js` fue comprobada con `node --check`.
- Se revisaron las referencias a las clases eliminadas y la presencia de rutas GET y CRUD.
- No fue posible compilar con Maven aquí: el wrapper intenta descargar Maven 3.10.0 y el entorno no tiene acceso a ese archivo. Probá `mvnw.cmd clean package` en tu equipo y después verificá el CRUD con PostgreSQL.
