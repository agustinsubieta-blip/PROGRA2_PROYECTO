# Rutas simplificadas

Se eliminó el prefijo `/api` de las rutas de inventario y se actualizaron las peticiones de `dashboard.js`.

| Recurso | GET | POST | PUT | DELETE |
| --- | --- | --- | --- | --- |
| Categorías | `/categories` | `/categories` | `/categories/{id}` | `/categories/{id}` |
| Productos | `/products` | `/products` | `/products/{id}` | `/products/{id}` |
| Proveedores | `/suppliers` | `/suppliers` | `/suppliers/{id}` | `/suppliers/{id}` |
| Almacenes | `/warehouses` | `/warehouses` | `/warehouses/{id}` | `/warehouses/{id}` |
| Stock (solo consulta) | `/stock`, `/stock/total-value` | — | — | — |

Las consultas de productos por categoría y almacén conservan sus rutas `/categories/{id}/products`, `/warehouses/{id}/categories` y `/warehouses/{warehouseId}/categories/{categoryId}/products`.

Los controladores administran su recurso correspondiente. Se eliminó `InventoryViewController.java`, y sus consultas se movieron a `ProductController`/`ProductService` y a `StockController`/`StockService`/`StockRepository`.

Spring Security: ADMIN puede eliminar; ADMIN y EMPLOYEE pueden crear/editar; VIEWER consulta; `/users/**` permanece exclusivo de ADMIN.

Nota de verificación: JavaScript pasó `node --check`. No fue posible compilar Java con Maven en este entorno porque el wrapper intentó descargar la distribución y no hubo acceso a ella. Recomendado probar localmente contra PostgreSQL.
